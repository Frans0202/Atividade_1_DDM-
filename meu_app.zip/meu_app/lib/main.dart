import 'package:flutter/material.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Meu currículo'),
          backgroundColor: Colors.deepPurple.shade50,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Pedro',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),


              const Row(
                children: [
                  Icon(Icons.email, size: 18),
                  SizedBox(width: 5),
                  Text('pedrofrans@gmail.com'),
                ],
              ),

              const SizedBox(height: 20),

              const Text(
                'Formação',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),

              const Text(
                'Análise e Desenvolvimento de Sistemas',
              ),

              const SizedBox(height: 15),

              const Text(
                'Habilidades',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),

              const Text('Fazer currículo pra celular'),
              const Text('Git e GitHub'),
            ],
          ),
        ),
      ),
    );
  }
}